package com.fortify.samples.riches.oper;

import com.fortify.samples.riches.AdminSupport;

public class Files extends AdminSupport
{

    public String execute() throws Exception
    {
        super.execute();
        return "success";
    }

}
