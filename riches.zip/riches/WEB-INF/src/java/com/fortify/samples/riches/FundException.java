package com.fortify.samples.riches;

public class FundException extends Exception {
	 public FundException(String message) {
        super(message);
    }
}
